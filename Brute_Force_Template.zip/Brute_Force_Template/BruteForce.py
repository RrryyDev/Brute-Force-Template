import selenium
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time

# Set up Chrome options
options = Options()
options.add_experimental_option("detach", True)

# Initialize the Chrome driver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

driver.get("https://thiagodnf.github.io/guess-the-code/")

ID1 = "n-0"
ID2 = "n-1"
ID3 = "n-2"

time.sleep(0.001)
box1 = driver.find_element(By.ID, ID1)
time.sleep(0.001)
box2 = driver.find_element(By.ID, ID2)
time.sleep(0.001)
box3 = driver.find_element(By.ID, ID3)

number = [0, 0, 0]

driver.maximize_window()

while True:

    if driver.find_element(By.ID, "btn-restart").text == "Restart Game":
        print(number)
        time.sleep()
        driver.quit()
        break

    box1.send_keys(number[0])
    #box1.clear()
    box1.send_keys(Keys.ENTER)
    box2.send_keys(number[1])
   # box2.clear()
    box2.send_keys(Keys.ENTER)
    box3.send_keys(number[2])
  #  box3.clear()
    box3.send_keys(Keys.ENTER)
    
    number[0] += 1
    if number[0] >= 10:
        number[1] += 1
        number[0] = 0
        if number[1] >= 10:
            number[2] += 1
            number[1] = 0
            if number[2] >= 10:
                break